
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    

with all_values as (

    select
        order_status as value_field,
        count(*) as n_records

    from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
    group by order_status

)

select *
from all_values
where value_field not in (
    'created','approved','invoiced','processing','shipped','delivered','canceled','unavailable'
)



  
  
      
    ) dbt_internal_test