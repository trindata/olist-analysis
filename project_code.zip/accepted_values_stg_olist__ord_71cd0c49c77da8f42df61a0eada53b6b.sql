
    
    

with all_values as (

    select
        review_score as value_field,
        count(*) as n_records

    from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_review`
    group by review_score

)

select *
from all_values
where value_field not in (
    1,2,3,4,5
)


