





with validation_errors as (

    select
        order_id, order_item_id
    from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_items`
    group by order_id, order_item_id
    having count(*) > 1

)

select *
from validation_errors


