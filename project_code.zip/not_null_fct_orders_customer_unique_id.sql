
    
    



select customer_unique_id
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`fct_orders`
where customer_unique_id is null


