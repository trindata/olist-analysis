
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select order_id
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`fct_orders`
where order_id is null



  
  
      
    ) dbt_internal_test