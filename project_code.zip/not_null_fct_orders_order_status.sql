
    
    



select order_status
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`fct_orders`
where order_status is null


