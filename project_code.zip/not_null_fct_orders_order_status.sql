
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select order_status
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`fct_orders`
where order_status is null



  
  
      
    ) dbt_internal_test