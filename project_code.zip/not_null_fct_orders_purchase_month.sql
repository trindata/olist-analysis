
    
    



select purchase_month
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`fct_orders`
where purchase_month is null


