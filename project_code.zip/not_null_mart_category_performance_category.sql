
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select category
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_category_performance`
where category is null



  
  
      
    ) dbt_internal_test