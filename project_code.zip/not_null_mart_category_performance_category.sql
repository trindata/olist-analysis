
    
    



select category
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_category_performance`
where category is null


