
    
    



select purchase_month
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_category_performance`
where purchase_month is null


