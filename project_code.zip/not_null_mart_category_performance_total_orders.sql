
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select total_orders
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_category_performance`
where total_orders is null



  
  
      
    ) dbt_internal_test