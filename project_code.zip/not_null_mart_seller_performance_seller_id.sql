
    
    



select seller_id
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_seller_performance`
where seller_id is null


