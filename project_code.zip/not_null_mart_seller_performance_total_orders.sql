
    
    



select total_orders
from `olist-funnel-analysis-494020`.`dbt_dev_marts`.`mart_seller_performance`
where total_orders is null


