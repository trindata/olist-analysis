
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select category_name_pt
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__category_translation`
where category_name_pt is null



  
  
      
    ) dbt_internal_test