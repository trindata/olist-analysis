
    
    



select category_name_pt
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__category_translation`
where category_name_pt is null


