
    
    



select customer_state
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__customers`
where customer_state is null


