
    
    



select customer_unique_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__customers`
where customer_unique_id is null


