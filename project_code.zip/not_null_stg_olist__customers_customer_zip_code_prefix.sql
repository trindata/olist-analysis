
    
    



select customer_zip_code_prefix
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__customers`
where customer_zip_code_prefix is null


