
    
    



select lat
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__geolocation`
where lat is null


