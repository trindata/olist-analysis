
    
    



select lng
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__geolocation`
where lng is null


