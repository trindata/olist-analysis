
    
    



select item_freight_value
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_items`
where item_freight_value is null


