
    
    



select item_price
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_items`
where item_price is null


