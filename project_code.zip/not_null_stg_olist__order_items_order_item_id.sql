
    
    



select order_item_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_items`
where order_item_id is null


