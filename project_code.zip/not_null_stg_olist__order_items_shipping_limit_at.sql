
    
    



select shipping_limit_at
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_items`
where shipping_limit_at is null


