
    
    



select payment_sequential
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_payments`
where payment_sequential is null


