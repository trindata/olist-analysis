
    
    



select payment_type
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_payments`
where payment_type is null


