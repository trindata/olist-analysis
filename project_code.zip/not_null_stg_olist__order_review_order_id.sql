
    
    



select order_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_review`
where order_id is null


