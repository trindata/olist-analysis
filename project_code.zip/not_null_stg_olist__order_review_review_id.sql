
    
    



select review_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_review`
where review_id is null


