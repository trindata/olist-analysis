
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select review_score
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_review`
where review_score is null



  
  
      
    ) dbt_internal_test