
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select estimated_delivery_at
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
where estimated_delivery_at is null



  
  
      
    ) dbt_internal_test