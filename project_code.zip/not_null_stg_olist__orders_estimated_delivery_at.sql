
    
    



select estimated_delivery_at
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
where estimated_delivery_at is null


