
    
    



select order_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
where order_id is null


