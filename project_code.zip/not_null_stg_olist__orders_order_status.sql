
    
    



select order_status
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
where order_status is null


