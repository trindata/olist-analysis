
    
    



select purchased_at
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
where purchased_at is null


