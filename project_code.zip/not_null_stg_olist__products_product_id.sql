
    
    



select product_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__products`
where product_id is null


