
    
    



select seller_id
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__sellers`
where seller_id is null


