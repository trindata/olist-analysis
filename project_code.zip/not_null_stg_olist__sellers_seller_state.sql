
    
    



select seller_state
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__sellers`
where seller_state is null


