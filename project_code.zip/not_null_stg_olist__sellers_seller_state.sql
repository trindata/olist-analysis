
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select seller_state
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__sellers`
where seller_state is null



  
  
      
    ) dbt_internal_test