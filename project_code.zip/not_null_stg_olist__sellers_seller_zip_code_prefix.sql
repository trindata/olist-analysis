
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select seller_zip_code_prefix
from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__sellers`
where seller_zip_code_prefix is null



  
  
      
    ) dbt_internal_test