
    
    

with child as (
    select customer_id as from_field
    from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__orders`
    where customer_id is not null
),

parent as (
    select customer_id as to_field
    from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__customers`
)

select
    from_field

from child
left join parent
    on child.from_field = parent.to_field

where parent.to_field is null


