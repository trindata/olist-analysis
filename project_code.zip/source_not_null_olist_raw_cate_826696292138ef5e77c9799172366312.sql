
    
    



select product_category_name
from `olist-funnel-analysis-494020`.`raw`.`category_name_translation`
where product_category_name is null


