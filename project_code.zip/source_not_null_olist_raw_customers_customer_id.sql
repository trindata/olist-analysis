
    
    



select customer_id
from `olist-funnel-analysis-494020`.`raw`.`customers`
where customer_id is null


