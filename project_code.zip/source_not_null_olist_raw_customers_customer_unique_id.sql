
    
    



select customer_unique_id
from `olist-funnel-analysis-494020`.`raw`.`customers`
where customer_unique_id is null


