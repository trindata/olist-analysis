
    
    



select order_item_id
from `olist-funnel-analysis-494020`.`raw`.`order_items`
where order_item_id is null


