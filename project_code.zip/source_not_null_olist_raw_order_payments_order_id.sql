
    
    



select order_id
from `olist-funnel-analysis-494020`.`raw`.`order_payments`
where order_id is null


