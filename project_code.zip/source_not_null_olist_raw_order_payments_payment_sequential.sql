
    
    



select payment_sequential
from `olist-funnel-analysis-494020`.`raw`.`order_payments`
where payment_sequential is null


