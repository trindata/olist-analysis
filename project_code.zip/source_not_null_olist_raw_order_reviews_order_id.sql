
    
    



select order_id
from `olist-funnel-analysis-494020`.`raw`.`order_reviews`
where order_id is null


