
    
    



select review_id
from `olist-funnel-analysis-494020`.`raw`.`order_reviews`
where review_id is null


