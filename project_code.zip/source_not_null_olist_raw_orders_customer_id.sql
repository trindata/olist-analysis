
    
    



select customer_id
from `olist-funnel-analysis-494020`.`raw`.`orders`
where customer_id is null


