
    
    



select order_id
from `olist-funnel-analysis-494020`.`raw`.`orders`
where order_id is null


