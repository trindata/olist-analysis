
    
    



select product_id
from `olist-funnel-analysis-494020`.`raw`.`products`
where product_id is null


