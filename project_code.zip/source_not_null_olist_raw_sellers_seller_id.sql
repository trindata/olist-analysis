
    
    



select seller_id
from `olist-funnel-analysis-494020`.`raw`.`sellers`
where seller_id is null


