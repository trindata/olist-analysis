

  create or replace view `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__category_translation`
  OPTIONS()
  as with source as (

    select * from `olist-funnel-analysis-494020`.`raw`.`category_name_translation`

),

renamed as (

    select
        product_category_name           as category_name_pt,
        product_category_name_english   as category_name_en

    from source

)

select * from renamed;

