

  create or replace view `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__customers`
  OPTIONS()
  as with source as (

    select * from `olist-funnel-analysis-494020`.`raw`.`customers`

),

renamed as (

    select
        -- ids
        customer_id,
        customer_unique_id,

        -- localização
        cast(customer_zip_code_prefix as string)  as customer_zip_code_prefix,
        initcap(trim(customer_city))              as customer_city,
        upper(trim(customer_state))               as customer_state

    from source

)

select * from renamed;

