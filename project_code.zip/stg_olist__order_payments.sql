

  create or replace view `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__order_payments`
  OPTIONS()
  as with source as (

    select * from `olist-funnel-analysis-494020`.`raw`.`order_payments`

),

renamed as (

    select
        -- ids (chave primária composta: order_id + payment_sequential)
        order_id,
        payment_sequential,

        -- atributos
        lower(trim(payment_type))           as payment_type,
        cast(payment_installments as int64) as payment_installments,
        cast(payment_value as numeric)      as payment_value

    from source

)

select * from renamed;

