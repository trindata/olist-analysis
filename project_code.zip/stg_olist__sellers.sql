

  create or replace view `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__sellers`
  OPTIONS()
  as with source as (

    select * from `olist-funnel-analysis-494020`.`raw`.`sellers`

),

renamed as (

    select
        -- ids
        seller_id,

        -- localização
        cast(seller_zip_code_prefix as string)  as seller_zip_code_prefix,
        initcap(trim(seller_city))              as seller_city,
        upper(trim(seller_state))               as seller_state

    from source

)

select * from renamed;

