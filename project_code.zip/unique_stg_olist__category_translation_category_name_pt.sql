
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    

with dbt_test__target as (

  select category_name_pt as unique_field
  from `olist-funnel-analysis-494020`.`dbt_dev_staging`.`stg_olist__category_translation`
  where category_name_pt is not null

)

select
    unique_field,
    count(*) as n_records

from dbt_test__target
group by unique_field
having count(*) > 1



  
  
      
    ) dbt_internal_test